#include "Camera.h"

Camera* Camera::mainCamera = NULL;