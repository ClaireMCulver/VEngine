#pragma once

#ifndef GameName
#define GameName "Playground"
#endif // !GameName
const int GameVersion = 1;

const int32_t WindowSize[] = { 800, 600 };